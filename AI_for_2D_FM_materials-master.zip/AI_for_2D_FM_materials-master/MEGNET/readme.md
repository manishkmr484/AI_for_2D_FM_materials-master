Another published model that was used was the MEGNET (Materials Graph Network) Model which was used for property prediction of molecules and crystals (https://github.com/materialsvirtuallab/megnet). 
